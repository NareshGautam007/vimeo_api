<?php
namespace Vimeo\Exceptions;

/**
 * VimeoRequestException class for failure to make request.
 */
class VimeoRequestException extends \Exception implements ExceptionInterface
{
}
